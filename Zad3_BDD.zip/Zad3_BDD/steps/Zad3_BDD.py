from behave import *
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

@given('I am on the Poczta tab of wp.pl')
def step_impl(context):
    context.browser = webdriver.Firefox()
    context.browser.get("https://www.poczta.wp.pl")

@when('I log in by using wsb_bdd and stxnext_bdd')
def step_impl(context):
    login = context.browser.find_element_by_xpath('//*[@id="login"]')
    login.clear()
    login.send_keys('wsb_bdd')

    password = context.browser.find_element_by_xpath('//*[@id="password"]')
    password.clear()
    password.send_keys('stxnext_bdd')

    zaloguj = context.browser.find_element_by_xpath('//*[@id="btnSubmit"]')
    zaloguj.click()

@then('I am logged in in to poczta')
def step_impl(context):
    assert "załóż konto" not in context.browser.page_source
    context.browser.quit()

@when('I log in by using milena@user.com and test')
def step_impl(context):
    login = context.browser.find_element_by_xpath('//*[@id="login"]')
    login.clear()
    login.send_keys('milena@user.com')

    password = context.browser.find_element_by_xpath('//*[@id="password"]')
    password.clear()
    password.send_keys('test')

    zaloguj = context.browser.find_element_by_xpath('//*[@id="btnSubmit"]')
    zaloguj.click()

@then('I am not logged in in to poczta')
def step_impl(context):
    assert "Wyloguj" not in context.browser.page_source
    context.browser.quit()